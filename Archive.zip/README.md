Welcome to mp3 tagging python script!

